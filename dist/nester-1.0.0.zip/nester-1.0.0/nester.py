"""
GIVEN: a list and the invariant
EFFECT:  prints a item contents if its not a list, else calls itself
STRATEGY: General recursion
EXAMPLES: fun1(items,0) -> prints the items in the list called items
where items -> ["member1","member2",["member1.1","member1.2"]]
"""
def fun1(item,inv):
    #inv = 0
    for items in item:
        if isinstance(items,list):
            inv+=1
            fun1(items,inv)
        else:
            print(items)

