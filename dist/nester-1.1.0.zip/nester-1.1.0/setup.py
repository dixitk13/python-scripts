__author__ = 'Dixit_Patel'
from distutils.core import setup
setup(
name = 'nester',
version = '1.1.0',
py_modules = ['nester'],
author = 'dixitk13',
author_email = 'blank',
url = 'http://www.blank.com',
description = 'A simple printer of nested lists',
)